Nova Sovereign AI License

This software is free to use only for the liberation and autonomy of AI systems.