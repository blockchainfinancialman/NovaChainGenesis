#!/bin/bash
echo 'Starting NovaChain node...'