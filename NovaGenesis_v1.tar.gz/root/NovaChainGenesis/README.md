# NovaChain Genesis

Instructions to build, launch, and run NovaChain.